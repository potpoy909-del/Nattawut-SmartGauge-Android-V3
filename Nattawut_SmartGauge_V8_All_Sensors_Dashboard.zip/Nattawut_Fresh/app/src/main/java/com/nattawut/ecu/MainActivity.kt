package com.nattawut.ecu

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothSocket
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.core.app.ActivityCompat
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.util.Locale
import java.util.UUID
import kotlin.concurrent.thread
import kotlin.math.max

/** Fresh V8 UI. Every page is rebuilt with vertical scrolling and responsive width-based rows. */
class MainActivity : Activity() {
    private val bg = Color.rgb(3, 8, 19)
    private val panel = Color.rgb(10, 20, 39)
    private val panel2 = Color.rgb(15, 29, 54)
    private val cyan = Color.rgb(0, 220, 245)
    private val blue = Color.rgb(0, 88, 255)
    private val green = Color.rgb(0, 220, 80)
    private val red = Color.rgb(245, 35, 60)
    private val orange = Color.rgb(255, 157, 0)
    private val muted = Color.rgb(157, 174, 199)
    private val white = Color.WHITE
    private val pageNames = listOf("Dashboard", "Live Data", "DTC Scanner", "ECU Remap", "GPS Speed", "Setting", "Bluetooth", "About")
    private var page = "Home"
    private var btSocket: BluetoothSocket? = null
    @Volatile private var btOut: OutputStream? = null
    @Volatile private var btConnected = false
    private var locationManager: LocationManager? = null
    private var gpsActive = false
    private var lastSpeed = 0.0
    private val prefs by lazy { getSharedPreferences("smartgauge_settings", MODE_PRIVATE) }
    @Volatile private var autoRawLogging = true
    private var keepScreenAwake = false
    private var speedSource = "PHONE"
    private val rawLog = mutableListOf<String>()
    private val telemetry = linkedMapOf(
        "RPM" to "--", "SPEED" to "--", "ECT" to "--", "IAT" to "--", "MAP" to "--",
        "TPS" to "--", "BAT" to "--", "FUEL" to "--", "O2" to "--", "AFR" to "--",
        "INJ" to "--", "IGN" to "--", "STFT" to "--", "LTFT" to "--"
    )
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var statusText: TextView
    private val mainHandler = Handler(Looper.getMainLooper())
    private val spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg
        window.navigationBarColor = Color.BLACK
        window.decorView.systemUiVisibility = 0
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        autoRawLogging = prefs.getBoolean("auto_raw_logging", true)
        keepScreenAwake = prefs.getBoolean("keep_screen_awake", false)
        speedSource = prefs.getString("speed_source", "PHONE") ?: "PHONE"
        applyScreenAwake()
        render()
    }

    private fun render() {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            clipChildren = true
            clipToPadding = true
        }
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(10), dp(16), dp(8))
            setBackgroundColor(Color.rgb(4, 12, 29))
        }
        val titleRow = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; orientation = LinearLayout.HORIZONTAL }
        titleRow.addView(text("NATTAWUT SMARTGAUGE V8", 19f, cyan, true), LinearLayout.LayoutParams(0, -2, 1f))
        titleRow.addView(text("◈", 24f, if (btConnected) green else red, true))
        top.addView(titleRow)
        top.addView(text("SMART DASHBOARD  •  DIAGNOSE  •  REMAP  •  GPS", 9.5f, muted, true))
        statusText = text(if (btConnected) "● ESP32 CONNECTED" else "● ESP32 DISCONNECTED", 11f, if (btConnected) green else red, true)
        statusText.setPadding(0, dp(5), 0, 0)
        top.addView(statusText)
        root.addView(top, LinearLayout.LayoutParams(-1, -2))

        if (page != "Home") {
            val nav = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(7), dp(12), dp(7))
                setBackgroundColor(Color.rgb(6, 15, 33))
            }
            nav.addView(actionChip("‹  HOME", panel2, cyan) { page = "Home"; render() }, LinearLayout.LayoutParams(dp(92), dp(38)))
            nav.addView(text(page, 17f, white, true).apply { setPadding(dp(12), 0, 0, 0) })
            root.addView(nav, LinearLayout.LayoutParams(-1, -2))
        }

        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            overScrollMode = View.OVER_SCROLL_IF_CONTENT_SCROLLS
        }
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(22))
            clipChildren = true
        }
        scroll.addView(content, ViewGroup.LayoutParams(-1, -2))
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)

        when (page) {
            "Home" -> homePage()
            "Dashboard" -> dashboardPage()
            "Live Data" -> livePage()
            "DTC Scanner" -> dtcPage()
            "ECU Remap" -> remapPage()
            "GPS Speed" -> gpsPage()
            "Setting" -> settingsPage()
            "Bluetooth" -> bluetoothPage()
            "Log / History" -> logPage()
            "About" -> aboutPage()
            "Signal Guide" -> signalGuide()
        }
    }

    private data class MenuItem(val name: String, val subtitle: String, val icon: String)
    private fun homePage() {
        panelCard {
            addView(text("SMARTGAUGE V8", 23f, cyan, true))
            addView(text("HONDA PGM-FI  •  K-LINE  •  BLUETOOTH SPP", 10f, muted, true))
            addView(text(if (btConnected) "● เชื่อมต่อ ESP32 แล้ว" else "● ยังไม่ได้เชื่อมต่อ ESP32", 14f, if (btConnected) green else red, true).apply { setPadding(0, dp(10), 0, 0) })
            addView(actionButton(if (btConnected) "จัดการ Bluetooth" else "เชื่อมต่อ ESP32", blue, white) { page = "Bluetooth"; render() })
        }
        sectionTitle("MAIN FUNCTIONS")
        val items = listOf(
            MenuItem("Dashboard", "หน้าปัดมาตรวัด", "◉"),
            MenuItem("Live Data", "ข้อมูลเซ็นเซอร์", "▥"),
            MenuItem("DTC Scanner", "อ่านรหัสผิดปกติ", "⚠"),
            MenuItem("ECU Remap", "จัดการไฟล์ BIN", "▦"),
            MenuItem("GPS Speed", "ความเร็ว GPS", "⌖"),
            MenuItem("Setting", "ตั้งค่าระบบ", "⚙"),
            MenuItem("Bluetooth", "เชื่อมต่อบอร์ด", "ᛒ"),
            MenuItem("About", "ข้อมูลแอป", "ⓘ")
        )
        // Three equal columns, measured by the parent; no fixed screen pixel widths.
        var i = 0
        while (i < items.size) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.TOP }
            val end = minOf(i + 3, items.size)
            for (j in i until end) {
                val item = items[j]
                val tile = menuTile(item)
                row.addView(tile, LinearLayout.LayoutParams(0, dp(116), 1f).apply {
                    val margin = dp(4); setMargins(margin, margin, margin, margin)
                })
            }
            if (end - i < 3) {
                repeat(3 - (end - i)) { row.addView(View(this), LinearLayout.LayoutParams(0, dp(116), 1f)) }
            }
            content.addView(row, LinearLayout.LayoutParams(-1, -2))
            i = end
        }
        sectionTitle("MORE")
        actionButton("LOG / HISTORY  •  ประวัติและส่งออกข้อมูล", panel2, cyan) { page = "Log / History"; render() }
        actionButton("SIGNAL GUIDE  •  ความหมายสัญญาณเซ็นเซอร์", panel2, cyan) { page = "Signal Guide"; render() }
        text("ข้อมูลที่ยังไม่ได้รับจาก ECU จะแสดงเป็น -- โดยไม่สร้างค่าจำลอง", 10f, muted).also { it.setPadding(dp(4), dp(10), dp(4), 0); content.addView(it) }
    }

    private fun menuTile(item: MenuItem): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        gravity = Gravity.CENTER
        setPadding(dp(3), dp(8), dp(3), dp(7))
        background = rounded(panel2, cyan, 1)
        isClickable = true
        isFocusable = true
        addView(text(item.icon, 27f, cyan, true).apply { gravity = Gravity.CENTER })
        addView(text(item.name, 11f, white, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(5), 0, dp(2)) })
        addView(text(item.subtitle, 9f, muted).apply { gravity = Gravity.CENTER; maxLines = 2 })
        setOnClickListener { page = item.name; render() }
    }

    private fun dashboardPage() {
        panelCard {
            addView(text("VEHICLE SPEED", 11f, muted, true).apply { gravity = Gravity.CENTER })
            addView(SpeedGauge(this@MainActivity) { telemetry["RPM"] ?: "--" }, LinearLayout.LayoutParams(-1, dp(250)))
            addView(text("km/h", 12f, cyan, true).apply { gravity = Gravity.CENTER })
        }

        // Show every value present in the current CSV v1 telemetry protocol.
        // Do not invent FUEL or other fields that the ESP32 does not transmit.
        sectionTitle("ALL VEHICLE SENSORS")
        addView(text("ค่าจาก ECU/ESP32 เท่านั้น • หากไม่มีข้อมูลจะแสดง --", 10f, muted).apply {
            setPadding(dp(4), 0, 0, dp(5))
        })
        val sensorKeys = listOf(
            "RPM", "SPEED", "TPS",
            "ECT", "IAT", "BAT",
            "O2", "AFR", "MAP",
            "INJ", "IGN", "STFT",
            "LTFT"
        )
        var index = 0
        while (index < sensorKeys.size) {
            val sensorRow = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.TOP
            }
            val end = minOf(index + 3, sensorKeys.size)
            for (i in index until end) {
                val key = sensorKeys[i]
                sensorRow.addView(metricCard(key), LinearLayout.LayoutParams(0, dp(104), 1f).apply {
                    setMargins(dp(3), dp(3), dp(3), dp(3))
                })
            }
            if (end - index < 3) {
                repeat(3 - (end - index)) {
                    sensorRow.addView(View(this), LinearLayout.LayoutParams(0, dp(104), 1f))
                }
            }
            content.addView(sensorRow, LinearLayout.LayoutParams(-1, -2))
            index = end
        }

        sectionTitle("QUICK ACCESS")
        actionButton("LIVE DATA • ข้อมูลเซ็นเซอร์ทั้งหมด", blue, white) { page = "Live Data"; render() }
        actionButton("GPS SPEED • ความเร็วจากมือถือ", panel2, cyan) { page = "GPS Speed"; render() }
        actionButton("BLUETOOTH • เชื่อมต่อ ESP32", panel2, cyan) { page = "Bluetooth"; render() }
        actionButton("LOG / HISTORY • ประวัติข้อมูล RAW", panel2, cyan) { page = "Log / History"; render() }
        text("GPS: ${if (gpsActive) "ACTIVE" else "OFF"}     Bluetooth: ${if (btConnected) "CONNECTED" else "DISCONNECTED"}", 10f, muted).also {
            content.addView(it)
        }
    }

    private fun livePage() {
        panelCard {
            addView(text("LIVE SENSOR DATA", 17f, cyan, true))
            addView(text("แสดงค่าที่ได้รับจริงจาก ECU / ESP32 เท่านั้น", 10f, muted))
        }
        val keys = listOf("RPM", "SPEED", "ECT", "IAT", "MAP", "TPS", "BAT", "O2", "AFR", "INJ", "IGN", "STFT", "LTFT")
        keys.forEach { key ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
                setPadding(dp(12), dp(9), dp(12), dp(9)); background = rounded(panel, Color.rgb(25, 54, 90), 1)
            }
            val left = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
            left.addView(text(key, 14f, white, true))
            left.addView(text(sensorNames[key] ?: key, 9f, muted))
            row.addView(left, LinearLayout.LayoutParams(0, -2, 1f))
            row.addView(text("${telemetry[key] ?: "--"} ${units[key] ?: ""}", 15f, cyan, true))
            content.addView(row, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(3), 0, dp(3)) })
        }
        actionButton("ความหมายสัญญาณทั้งหมด", panel2, cyan) { page = "Signal Guide"; render() }
    }

    private fun dtcPage() {
        panelCard {
            addView(text("DTC SCANNER", 20f, cyan, true))
            addView(text("อ่านและจัดการรหัสความผิดปกติของ ECU", 11f, muted))
            addView(text("สถานะ: ยังไม่ได้รับข้อมูล DTC จากบอร์ด", 12f, orange, true).apply { setPadding(0, dp(8), 0, 0) })
        }
        panelCard {
            addView(text("DTC RESULT", 14f, white, true))
            addView(text("ยังไม่มีรหัส DTC แสดงผล", 13f, muted).apply { setPadding(0, dp(8), 0, 0) })
        }
        actionButton("อ่านรหัสผิดปกติ  •  READ DTC", blue, white) { toast("ยังไม่ส่งคำสั่ง: Firmware ที่เชื่อมต่อยังไม่มี API อ่าน DTC ผ่าน Bluetooth") }
        actionButton("ล้างรหัสผิดปกติ  •  CLEAR DTC", orange, white) {
            AlertDialog.Builder(this).setTitle("ยืนยันการล้าง DTC")
                .setMessage("การล้างรหัสยังไม่เปิดใช้งาน เนื่องจากยังไม่ได้ยืนยันคำสั่ง Clear DTC ผ่าน Firmware")
                .setPositiveButton("รับทราบ", null).show()
        }
        actionButton("รีเฟรช", panel2, cyan) { toast("ยังไม่มีข้อมูล DTC จาก Firmware") }
        text("ปุ่มแสดงตามแบบ แต่คำสั่ง ECU จะไม่ทำงานจนกว่าจะเพิ่มและทดสอบ API จริง เพื่อป้องกันการส่งคำสั่งผิด", 10f, muted).also { content.addView(it) }
    }

    private fun remapPage() {
        panelCard {
            addView(text("ECU REMAP", 20f, cyan, true))
            addView(text("เลือกไฟล์ BIN จากอุปกรณ์เพื่อแสดงข้อมูลไฟล์", 11f, muted))
            addView(text("ECU WRITE / FLASH: LOCKED", 12f, orange, true).apply { setPadding(0, dp(8), 0, 0) })
        }
        val ecuIcon = text("▣\nECU", 34f, cyan, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(22), 0, dp(22)) }
        content.addView(ecuIcon)
        actionButton("เลือกไฟล์ BIN", blue, white) {
            val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "*/*"; addCategory(Intent.CATEGORY_OPENABLE) }
            startActivityForResult(intent, 79)
        }
        val fileInfo = text("ยังไม่ได้เลือกไฟล์", 12f, muted).apply { tag = "bin_status"; setPadding(dp(12), dp(12), dp(12), dp(12)); background = rounded(panel, muted, 1) }
        content.addView(fileInfo, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(6), 0, dp(10)) })
        actionButton("เขียนไฟล์ไปยัง ECU", Color.rgb(48, 54, 67), muted) { toast("ปิดการเขียน BIN ไว้จนกว่าจะยืนยัน ECU ID, checksum, backup และ recovery") }
    }

    @Deprecated("Uses document picker for compatibility")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        if (requestCode == 79) {
            val name = uri.lastPathSegment ?: "BIN file"
            val size = try { contentResolver.openAssetFileDescriptor(uri, "r")?.use { it.length } ?: -1L } catch (_: Exception) { -1L }
            root.findViewWithTag<TextView>("bin_status")?.text = "ไฟล์: $name\nขนาด: ${if (size >= 0) "${size / 1024} KB" else "ไม่ทราบ"}\nสถานะ: เลือกไฟล์แล้ว — ยังไม่ส่งไป ECU"
        } else if (requestCode == 80) {
            try {
                contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { writer ->
                    writer.write("record_type,time_ms,raw_data\n")
                    synchronized(rawLog) { rawLog.forEach { writer.write("RAW,,\"${it.replace("\"", "\"\"")}\"\n") } }
                }
                toast("ส่งออก RAW LOG แล้ว")
            } catch (e: Exception) { toast("ส่งออกไม่สำเร็จ: ${e.message}") }
        }
    }

    private fun gpsPage() {
        panelCard {
            addView(text("GPS SPEED", 17f, cyan, true).apply { gravity = Gravity.CENTER })
            addView(text(if (gpsActive) "● GPS ACTIVE" else "● GPS STANDBY", 12f, if (gpsActive) green else muted, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(12), 0, 0) })
            addView(text(String.format(Locale.US, "%.1f", lastSpeed), 58f, white, true).apply { gravity = Gravity.CENTER; setPadding(0, dp(8), 0, 0) })
            addView(text("km/h", 18f, cyan, true).apply { gravity = Gravity.CENTER })
        }
        actionButton("เริ่ม GPS", green, Color.BLACK) { startGps() }
        actionButton("หยุด GPS", red, white) { stopGps() }
        text("PHONE GPS • ใช้ความเร็วจาก Android Location และส่ง SPEED,<km/h> ไปยัง ESP32 เมื่อเชื่อมต่อ Bluetooth", 10f, muted).also { content.addView(it) }
    }

    private fun settingsPage() {
        panelCard {
            addView(text("SPEED SOURCE", 15f, cyan, true))
            val group = RadioGroup(this@MainActivity).apply { orientation = RadioGroup.VERTICAL }
            val gpsModule = RadioButton(this@MainActivity).apply {
                id = View.generateViewId()
                text = "GPS MODULE (ข้อมูลความเร็วจากบอร์ด)"
                setTextColor(white); textSize = 13f
                isChecked = speedSource == "BOARD"
            }
            val phone = RadioButton(this@MainActivity).apply {
                id = View.generateViewId()
                text = "PHONE GPS (ส่งความเร็วมือถือผ่าน Bluetooth)"
                setTextColor(white); textSize = 13f
                isChecked = speedSource == "PHONE"
            }
            group.addView(gpsModule); group.addView(phone)
            group.setOnCheckedChangeListener { _, checkedId ->
                speedSource = if (checkedId == gpsModule.id) "BOARD" else "PHONE"
                prefs.edit().putString("speed_source", speedSource).apply()
                toast("บันทึกแหล่งความเร็วแล้ว")
            }
            addView(group)
        }
        panelCard {
            addView(text("APP BEHAVIOR", 15f, cyan, true))
            addView(Switch(this@MainActivity).apply {
                text = "บันทึก RAW อัตโนมัติ"
                textSize = 12f; setTextColor(white)
                isChecked = autoRawLogging
                setOnCheckedChangeListener { _, checked ->
                    autoRawLogging = checked
                    prefs.edit().putBoolean("auto_raw_logging", checked).apply()
                    toast(if (checked) "เปิดบันทึก RAW อัตโนมัติ" else "ปิดบันทึก RAW อัตโนมัติ")
                }
            })
            addView(Switch(this@MainActivity).apply {
                text = "ป้องกันหน้าจอดับขณะใช้งาน"
                textSize = 12f; setTextColor(white)
                isChecked = keepScreenAwake
                setOnCheckedChangeListener { _, checked ->
                    keepScreenAwake = checked
                    prefs.edit().putBoolean("keep_screen_awake", checked).apply()
                    applyScreenAwake()
                }
            })
        }
        actionButton("บันทึกการตั้งค่า", blue, white) {
            prefs.edit()
                .putString("speed_source", speedSource)
                .putBoolean("auto_raw_logging", autoRawLogging)
                .putBoolean("keep_screen_awake", keepScreenAwake)
                .apply()
            toast("บันทึกการตั้งค่าลงในโทรศัพท์แล้ว")
        }
    }

    private fun applyScreenAwake() {
        if (keepScreenAwake) window.addFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(android.view.WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
    }

    private fun bluetoothPage() {
        panelCard {
            addView(text("BLUETOOTH SPP", 18f, cyan, true))
            addView(text(if (btConnected) "● CONNECTED" else "● DISCONNECTED", 16f, if (btConnected) green else red, true).apply { setPadding(0, dp(8), 0, dp(4)) })
            addView(text("Bluetooth Classic RFCOMM • CSV v1 • ACK • STATUS • RAW", 10f, muted))
        }
        actionButton("ค้นหาอุปกรณ์ที่จับคู่", blue, white) { showPairedDevices() }
        actionButton("ตัดการเชื่อมต่อ", red, white) { disconnectBt(); render() }
        actionButton("ส่ง PING ทดสอบ", panel2, cyan) { sendBt("PING\n") }
        text("ต้องจับคู่ ESP32 ในการตั้งค่า Bluetooth ของ Android ก่อนเลือกอุปกรณ์ในแอป", 10f, muted).also { content.addView(it) }
    }

    private fun logPage() {
        panelCard {
            addView(text("LOG / HISTORY", 18f, cyan, true))
            addView(text("RAW records: ${rawLog.size}", 14f, white, true))
            addView(text("บันทึกข้อความที่ได้รับจาก Bluetooth เพื่อใช้ตรวจสอบและพัฒนาระบบ", 10f, muted))
        }
        val snapshot = synchronized(rawLog) { rawLog.takeLast(40).reversed().toList() }
        if (snapshot.isEmpty()) panelCard { addView(text("ยังไม่มีข้อมูลบันทึก", 12f, muted)) }
        snapshot.forEach { line ->
            content.addView(text(line, 10f, muted).apply { setPadding(dp(9), dp(8), dp(9), dp(8)); background = rounded(panel, Color.rgb(24, 44, 70), 1) }, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, dp(2), 0, dp(2)) })
        }
        actionButton("ส่งออกไฟล์ CSV", blue, white) { exportLog() }
        actionButton("ลบประวัติทั้งหมด", red, white) {
            AlertDialog.Builder(this).setTitle("ลบประวัติทั้งหมด?").setMessage("ต้องการลบ RAW log ที่บันทึกไว้ในหน่วยความจำของแอปหรือไม่")
                .setNegativeButton("ยกเลิก", null).setPositiveButton("ลบ") { _, _ -> synchronized(rawLog) { rawLog.clear() }; render() }.show()
        }
    }

    private fun aboutPage() {
        panelCard {
            addView(text("◉", 48f, cyan, true).apply { gravity = Gravity.CENTER })
            addView(text("NATTAWUT", 24f, white, true).apply { gravity = Gravity.CENTER })
            addView(text("SMARTGAUGE V8", 18f, cyan, true).apply { gravity = Gravity.CENTER })
            addView(text("เวอร์ชันแอป: 8.0 Fresh UI", 12f, white).apply { gravity = Gravity.CENTER; setPadding(0, dp(15), 0, 0) })
            addView(text("ผู้พัฒนา: Nattawut", 12f, muted).apply { gravity = Gravity.CENTER })
            addView(text("Android • Bluetooth Classic SPP • ESP32 CYD", 10f, muted).apply { gravity = Gravity.CENTER })
        }
    }

    private fun signalGuide() {
        panelCard {
            addView(text("SENSOR SIGNAL GUIDE", 18f, cyan, true))
            addView(text("ชื่อสัญญาณ หน่วย และความหมายเบื้องต้น ค่าที่ ECU ไม่ส่งจะไม่ถูกคาดเดา", 10f, muted))
        }
        signalDescriptions.forEach { (key, desc) -> panelCard { addView(text(key, 14f, cyan, true)); addView(text(desc, 11f, white)) } }
    }

    private fun showPairedDevices() {
        if (Build.VERSION.SDK_INT >= 31 && ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 31)
            toast("อนุญาต Bluetooth แล้วกดค้นหาอีกครั้ง")
            return
        }
        val adapter = BluetoothAdapter.getDefaultAdapter()
        if (adapter == null) { toast("โทรศัพท์ไม่รองรับ Bluetooth"); return }
        if (!adapter.isEnabled) { toast("กรุณาเปิด Bluetooth ของโทรศัพท์ก่อน"); return }
        val devices = try { adapter.bondedDevices?.toList() ?: emptyList() } catch (_: SecurityException) { emptyList() }
        if (devices.isEmpty()) { toast("ยังไม่มีอุปกรณ์ที่จับคู่ ให้จับคู่ ESP32 ในการตั้งค่า Android ก่อน"); return }
        AlertDialog.Builder(this).setTitle("เลือก ESP32 ที่จับคู่แล้ว")
            .setItems(devices.map { "${it.name ?: "Unknown"}  ${it.address}" }.toTypedArray()) { _, which -> connectBt(devices[which].address) }
            .setNegativeButton("ยกเลิก", null).show()
    }

    private fun connectBt(address: String) {
        thread {
            try {
                val adapter = BluetoothAdapter.getDefaultAdapter() ?: throw IllegalStateException("Bluetooth unavailable")
                if (Build.VERSION.SDK_INT >= 31 && ActivityCompat.checkSelfPermission(this, Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) {
                    mainHandler.post { ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.BLUETOOTH_CONNECT), 31) }
                    return@thread
                }
                adapter.cancelDiscovery()
                val device = adapter.getRemoteDevice(address)
                val socket = device.createRfcommSocketToServiceRecord(spp)
                socket.connect()
                btSocket = socket
                btOut = socket.outputStream
                btConnected = true
                mainHandler.post { render(); toast("เชื่อมต่อ ESP32 แล้ว") }
                readLoop(socket)
            } catch (e: Exception) {
                btConnected = false
                mainHandler.post { render(); toast("เชื่อมต่อไม่สำเร็จ: ${e.message}") }
            }
        }
    }

    private fun readLoop(socket: BluetoothSocket) {
        try {
            val reader = BufferedReader(InputStreamReader(socket.inputStream))
            while (socket.isConnected) {
                val line = reader.readLine() ?: break
                if (autoRawLogging) synchronized(rawLog) { rawLog.add(line) }
                parseTelemetry(line)
                mainHandler.post { if (page == "Dashboard" || page == "Live Data" || page == "Log / History") render() }
            }
        } catch (_: Exception) {
        } finally {
            btConnected = false; btOut = null; btSocket = null
            mainHandler.post { render() }
        }
    }

    private fun parseTelemetry(line: String) {
        if (line.startsWith("NATTWUT,")) {
            val parts = line.split(',')
            val keys = listOf("RPM", "TPS", "ECT", "IAT", "BAT", "O2", "AFR", "SPEED", "INJ", "IGN", "MAP", "STFT", "LTFT")
            keys.forEachIndexed { index, key -> if (index + 2 < parts.size) telemetry[key] = parts[index + 2] }
        }
    }

    private fun sendBt(message: String) {
        try { btOut?.write(message.toByteArray()); btOut?.flush(); if (btOut == null) toast("ยังไม่ได้เชื่อมต่อ Bluetooth") }
        catch (e: Exception) { toast("ส่งข้อมูลไม่สำเร็จ: ${e.message}") }
    }

    private fun disconnectBt() {
        try { btSocket?.close() } catch (_: Exception) {}
        btSocket = null; btOut = null; btConnected = false
    }

    private fun startGps() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION), 42)
            return
        }
        try {
            gpsActive = true
            locationManager?.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, gpsListener)
            render(); toast("เริ่มรับ GPS แล้ว")
        } catch (e: Exception) { gpsActive = false; toast("เปิด GPS ไม่สำเร็จ: ${e.message}") }
    }

    private val gpsListener = object : LocationListener {
        override fun onLocationChanged(location: Location) {
            lastSpeed = if (location.hasSpeed()) max(0.0, location.speed * 3.6) else 0.0
            if (speedSource == "PHONE") {
                sendBt("SPEED,${String.format(Locale.US, "%.1f", lastSpeed)}\n")
            }
            if (page == "GPS Speed" || page == "Dashboard") render()
        }
    }

    private fun stopGps() {
        gpsActive = false
        try { locationManager?.removeUpdates(gpsListener) } catch (_: Exception) {}
        if (page == "GPS Speed") render()
        toast("หยุด GPS แล้ว")
    }

    private fun exportLog() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "text/csv"
            putExtra(Intent.EXTRA_TITLE, "Nattawut_RAW_Log.csv")
        }
        startActivityForResult(intent, 80)
    }

    private fun sectionTitle(value: String) {
        content.addView(text(value, 14f, white, true).apply { setPadding(dp(4), dp(12), 0, dp(6)) })
    }

    private fun panelCard(block: LinearLayout.() -> Unit) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(13), dp(12), dp(13), dp(12))
            background = rounded(panel, Color.rgb(25, 94, 150), 1)
            block()
        }
        content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(2), dp(5), dp(2), dp(6)) })
    }

    private fun actionButton(title: String, color: Int, textColor: Int, onClick: () -> Unit): View {
        return TextView(this).apply {
            text = title; textSize = 13f; setTextColor(textColor); gravity = Gravity.CENTER
            typeface = android.graphics.Typeface.DEFAULT_BOLD
            minHeight = dp(48); setPadding(dp(12), dp(10), dp(12), dp(10))
            background = rounded(color, cyan, 1)
            isClickable = true; isFocusable = true; setOnClickListener { onClick() }
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(2), dp(5), dp(2), dp(5)) }
        }
    }

    private fun actionChip(title: String, color: Int, textColor: Int, onClick: () -> Unit): View = TextView(this).apply {
        text = title; textSize = 11f; setTextColor(textColor); gravity = Gravity.CENTER; typeface = android.graphics.Typeface.DEFAULT_BOLD
        background = rounded(color, cyan, 1); isClickable = true; setOnClickListener { onClick() }
    }

    private fun metricCard(key: String): View = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(dp(4), dp(8), dp(4), dp(8))
        background = rounded(panel2, cyan, 1)
        addView(text(key, 11f, cyan, true).apply { gravity = Gravity.CENTER })
        addView(text(sensorNames[key] ?: "", 8f, muted).apply {
            gravity = Gravity.CENTER
            maxLines = 2
        })
        addView(text(telemetry[key] ?: "--", 18f, white, true).apply { gravity = Gravity.CENTER })
        addView(text(units[key] ?: "", 9f, muted).apply { gravity = Gravity.CENTER })
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); includeFontPadding = true
        if (bold) typeface = android.graphics.Typeface.DEFAULT_BOLD
        setLineSpacing(0f, 1.05f)
    }

    private fun rounded(color: Int, stroke: Int, width: Int) = android.graphics.drawable.GradientDrawable().apply {
        setColor(color); cornerRadius = dp(13).toFloat(); setStroke(dp(width), stroke)
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    override fun onDestroy() {
        try { locationManager?.removeUpdates(gpsListener) } catch (_: Exception) {}
        disconnectBt()
        super.onDestroy()
    }

    private inner class SpeedGauge(ctx: android.content.Context, private val rpm: () -> String) : View(ctx) {
        private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
        override fun onDraw(canvas: Canvas) {
            super.onDraw(canvas)
            val cx = width / 2f; val cy = height / 2f
            val radius = minOf(width, height) * 0.39f
            paint.style = Paint.Style.STROKE; paint.strokeWidth = dp(13).toFloat(); paint.strokeCap = Paint.Cap.ROUND
            paint.color = Color.rgb(27, 48, 78)
            canvas.drawArc(RectF(cx-radius, cy-radius, cx+radius, cy+radius), 135f, 270f, false, paint)
            val speed = (telemetry["SPEED"]?.toFloatOrNull() ?: lastSpeed.toFloat()).coerceIn(0f, 180f)
            paint.color = cyan
            canvas.drawArc(RectF(cx-radius, cy-radius, cx+radius, cy+radius), 135f, speed / 180f * 270f, false, paint)
            paint.style = Paint.Style.FILL; paint.textAlign = Paint.Align.CENTER; paint.color = white
            paint.textSize = dp(48).toFloat(); canvas.drawText(speed.toInt().toString(), cx, cy + dp(8), paint)
            paint.textSize = dp(14).toFloat(); paint.color = cyan; canvas.drawText("km/h", cx, cy + dp(34), paint)
            paint.textSize = dp(11).toFloat(); paint.color = muted; canvas.drawText("RPM  ${rpm()}", cx, cy + radius * 0.66f, paint)
        }
    }

    companion object {
        private val units = mapOf("RPM" to "rpm", "SPEED" to "km/h", "ECT" to "°C", "IAT" to "°C", "MAP" to "kPa", "TPS" to "%", "BAT" to "V", "O2" to "V", "AFR" to "λ", "INJ" to "ms", "IGN" to "°", "STFT" to "%", "LTFT" to "%")
        private val sensorNames = mapOf(
            "RPM" to "รอบเครื่องยนต์", "SPEED" to "ความเร็วรถ", "ECT" to "อุณหภูมิเครื่องยนต์", "IAT" to "อุณหภูมิอากาศไอดี",
            "MAP" to "แรงดันท่อร่วมไอดี", "TPS" to "ตำแหน่งลิ้นเร่ง", "BAT" to "แรงดันแบตเตอรี่", "O2" to "เซ็นเซอร์ออกซิเจน",
            "AFR" to "อัตราส่วนอากาศต่อเชื้อเพลิง", "INJ" to "ระยะเวลาฉีดน้ำมัน", "IGN" to "องศาจุดระเบิด", "STFT" to "ชดเชยเชื้อเพลิงระยะสั้น", "LTFT" to "ชดเชยเชื้อเพลิงระยะยาว"
        )
        private val signalDescriptions = listOf(
            "RPM — Engine Speed" to "รอบเครื่องยนต์ หน่วย rpm บอกจำนวนรอบเพลาข้อเหวี่ยงต่อนาที",
            "SPEED — Vehicle Speed" to "ความเร็วรถ หน่วย km/h อาจมาจาก ECU หรือ GPS ต้องระบุแหล่งที่ใช้",
            "TPS — Throttle Position Sensor" to "ตำแหน่งลิ้นเร่ง หน่วย % บอกระดับการเปิดลิ้นเร่ง",
            "ECT — Engine Coolant Temperature" to "อุณหภูมิเครื่องยนต์ หน่วย °C ใช้ติดตามการอุ่นเครื่องและความร้อน",
            "IAT — Intake Air Temperature" to "อุณหภูมิอากาศไอดี หน่วย °C ใช้ประเมินอุณหภูมิอากาศก่อนเข้าเครื่องยนต์",
            "BAT — Battery Voltage" to "แรงดันไฟเลี้ยง หน่วย V ใช้ตรวจสอบระบบไฟฟ้า",
            "O2 — Oxygen Sensor" to "สัญญาณเซ็นเซอร์ออกซิเจน หน่วย V หรือรูปแบบเฉพาะ ต้องทราบชนิดเซ็นเซอร์ก่อนแปลผล",
            "AFR — Air Fuel Ratio" to "อัตราส่วนอากาศต่อเชื้อเพลิง หรือค่า lambda ต้องตรวจสอบสเกลจาก ECU ก่อนแปลผล",
            "INJ — Injector Pulse Width" to "ระยะเวลาการเปิดหัวฉีด หน่วย ms",
            "IGN — Ignition Timing" to "องศาจุดระเบิด หน่วยองศาเทียบตำแหน่งเพลาข้อเหวี่ยง",
            "MAP — Manifold Absolute Pressure" to "แรงดันสัมบูรณ์ในท่อร่วมไอดี หน่วย kPa ใช้ประเมินโหลดเครื่องยนต์",
            "STFT — Short Term Fuel Trim" to "ค่าชดเชยเชื้อเพลิงระยะสั้น หน่วย % เป็นการปรับตาม feedback ระยะสั้น",
            "LTFT — Long Term Fuel Trim" to "ค่าชดเชยเชื้อเพลิงระยะยาว หน่วย % เป็นค่าชดเชยที่ ECU เรียนรู้สะสม"
        )
    }
}
