# ตั้งค่าความเร็ว GPS สำหรับ NATTAWUT SMARTGAUGE

ระบบความเร็วมี 2 แหล่งเท่านั้น และไม่อ่าน SPEED จาก ECU

## 1) PHONE GPS
1. ติดตั้งแอปที่ Build จาก source ZIP นี้
2. เปิด Bluetooth และเชื่อมต่ออุปกรณ์ `Nattawut ECU`
3. เปิดหน้า GPS แล้วเลือก `PHONE GPS`
4. อนุญาต Location แบบ Precise และเปิด Location/GPS ของโทรศัพท์
5. เมื่อมือถือได้ GPS fix แอปจะแสดง km/h และส่งคำสั่ง `SPEED,<km/h>` ไปยัง ESP32 ผ่าน Bluetooth SPP
6. ESP32 จะใช้ความเร็วจากมือถือแสดงบนหน้าจอบอร์ดด้วย

## 2) ESP32 GPS
1. ต่อโมดูล GPS เข้ากับ ESP32 ตามขาที่กำหนดใน Firmware
2. เปิดหน้า GPS ในแอปแล้วเลือก `ESP32 GPS`
3. ESP32 อ่าน NMEA จากโมดูล GPS และส่งความเร็วกลับมายังแอป

## คำสั่ง Bluetooth ที่เพิ่ม
- `SPEED_SOURCE,PHONE` เลือกความเร็วจากมือถือ
- `SPEED_SOURCE,GPS` เลือกโมดูล GPS บน ESP32
- `SPEED,<km/h>` ส่งความเร็วจาก GPS มือถือไปยัง ESP32
- `SPEED,NA` แจ้งว่า GPS มือถือไม่มี fix

เมื่อไม่มี GPS fix ทั้งแอปและบอร์ดจะแสดง `--` ไม่ใช้ความเร็วจาก ECU แทน
