# Nattawut SmartGauge V8 — Layout Rebuild

โปรเจกต์ Android สร้าง UI ใหม่โดยอ้างอิงโปสเตอร์ SmartGauge V8 ทั้ง 10 หน้า ไม่ได้นำ Activity/UI เดิมจาก Stage 3 มาใช้

## หน้าจอ
1. Home — เมนูหลัก 8 ช่องแบบ 3 คอลัมน์ พร้อมทางเข้า Log/History และ Signal Guide
2. Dashboard — มาตรวัดความเร็ววงกลมและค่าหลัก
3. Live Data — รายการสัญญาณและหน่วย
4. DTC Scanner — ผล DTC และปุ่ม Read/Clear/Refresh (คำสั่งจริงยังปิดจนกว่า Firmware API จะได้รับการยืนยัน)
5. ECU Remap — เลือกไฟล์ BIN และแสดงชื่อ/ขนาด (เขียน ECU ถูกล็อก)
6. GPS Speed — อ่าน GPS มือถือและส่ง SPEED,<km/h> ผ่าน SPP
7. Setting — เลือกแหล่งความเร็วและตัวเลือกการแสดงผล
8. Bluetooth — เลือกอุปกรณ์ที่จับคู่, connect/disconnect, PING
9. Log/History — แสดง RAW ที่รับและส่งออก CSV
10. About — ข้อมูลแอป

Signal Guide เป็นหน้าความรู้เพิ่มเติม ไม่ใช่หนึ่งใน 10 หน้าหลัก

## Layout safeguards
- ใช้ vertical ScrollView สำหรับเนื้อหาทุกหน้า
- ใช้ความกว้างแบบ match-parent และ weight สำหรับกริดเมนู 3 คอลัมน์
- ปุ่มเป็น View แบบกำหนด minHeight และ padding เอง ลดปัญหา Android Button inset/ขนาดปุ่มไม่สม่ำเสมอ
- ไม่มีการวางตำแหน่งแบบ absolute และไม่มีพิกัดหน้าจอตายตัว
- ค่าที่ไม่มีจาก ECU แสดง `--` ไม่สร้างข้อมูลจำลอง

## Build
ใช้ GitHub Actions workflow `.github/workflows/android-build.yml` เพื่อสร้าง Debug APK ด้วย JDK 17 และ Gradle 8.7

หมายเหตุ: ZIP นี้ยังไม่ได้ผ่านการ Build บน Android SDK ในสภาพแวดล้อมที่สร้างไฟล์ จึงต้องให้ GitHub Actions เป็นผู้ยืนยันการคอมไพล์จริง และต้องทดสอบบนโทรศัพท์ก่อนใช้งาน
