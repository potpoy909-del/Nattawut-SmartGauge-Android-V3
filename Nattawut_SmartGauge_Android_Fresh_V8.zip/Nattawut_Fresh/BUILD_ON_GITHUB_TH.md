# วิธี Build บน GitHub

1. อัปโหลด `Nattawut_SmartGauge_Android_Fresh_V8.zip` ไว้ที่ root ของ Repository
2. ตรวจสอบว่ามี workflow `.github/workflows/android-build.yml`
3. เปิดแท็บ Actions แล้วเลือก `Build Nattawut SmartGauge V8`
4. รอจนงานเป็นสีเขียว
5. เปิด run ที่สำเร็จ เลื่อนลงไปที่ Artifacts แล้วดาวน์โหลด `Nattawut-SmartGauge-V8-Layout-Rebuild-APK`
6. แตก ZIP Artifact และติดตั้ง `app-debug.apk`

หากงานเป็นสีแดง ให้เปิดขั้นตอน `Build debug APK` แล้วส่ง log ตั้งแต่บรรทัดแรกของ error เพื่อแก้จากสาเหตุจริง
