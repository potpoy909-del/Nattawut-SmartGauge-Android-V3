# NATTAWUT SMARTGAUGE V3 — Racing ECU UI

This project updates the Android app UI to follow the agreed Racing ECU design reference: Dashboard, Live Graph, DTC Diagnostics, ECU Information, MAP Manager, Remote Control, Bluetooth Manager, Settings, and RAW ECU Logger.

## Build APK

The repository workflow `.github/workflows/android-build.yml` builds `app-debug.apk` from this project. The Android project files (`settings.gradle`, `app/build.gradle`, etc.) are at the ZIP root.

## Important hardware/API status

- Bluetooth Classic SPP connection and existing telemetry CSV parser are retained.
- Missing ECU values (`NA`) are shown as `--`, not fabricated as zero.
- RAW Logger stores complete text lines received over Bluetooth during a capture session and exports CSV. It can preserve the ESP32 RAW frame messages if the installed firmware emits them.
- This is not a passive electrical K-Line sniffer. Frames not forwarded by the ESP32 firmware cannot be recovered by the app.
- DTC read/clear, MAP transfer, and remote hardware controls are shown as planned/locked where the current Bluetooth firmware API does not expose a verified command. The app does not send invented ECU commands.
- ECU identity/VIN are not fabricated. The ECU page distinguishes user-supplied vehicle/ECU context from data actually read in the current session.

## Firmware

`firmware/Nattawut_SmartGauge_V8_Base.ino` is the supplied V8 baseline. Preserve a backup before flashing. Firmware/app integration for RAW frame streaming and remote DTC operations still requires protocol-level verification and physical testing with the Honda Wave 110i S4 ECU.

## Version

Android versionName: `3.0-racing-ui` (UI update / integration stage; not a claim that every hardware feature is complete).


## Stage 3 menu expansion
- Added a redesigned SmartGauge home control center with ten menu destinations.
- Added ECU Remap BIN file selection and basic file metadata display only.
- ECU BIN writing/flashing remains locked; no ECU write command is sent by the app.
- DTC app buttons remain unavailable until a verified Bluetooth DTC API is added to the board firmware. Existing on-board DTC operation remains separate.
- Preserved existing Bluetooth SPP telemetry, graph, logger, and existing pages.
