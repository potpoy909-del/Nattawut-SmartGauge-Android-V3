# NATTAWUT SMARTGAUGE V3 — Racing ECU UI

This project updates the Android app UI to follow the agreed Racing ECU design reference: Dashboard, Live Graph, DTC Diagnostics, ECU Information, MAP Manager, Remote Control, Bluetooth Manager, Settings, and RAW ECU Logger.

## Build APK

The repository workflow `.github/workflows/android-build.yml` builds `app-debug.apk` from this project. The Android project files (`settings.gradle`, `app/build.gradle`, etc.) are at the ZIP root.

## Important hardware/API status

- Bluetooth Classic SPP connection and existing telemetry CSV parser are retained.
- Missing ECU values (`NA`) are shown as `--`, not fabricated as zero.
- RAW Logger stores complete text lines received over Bluetooth during a capture session and exports CSV. It can preserve the ESP32 RAW frame messages if the installed firmware emits them.
- This is not a passive electrical K-Line sniffer. Frames not forwarded by the ESP32 firmware cannot be recovered by the app.
- DTC read/clear, MAP transfer, and remote hardware controls are shown as planned/locked where the current Bluetooth firmware API does not expose a verified command. The app does not send invented ECU commands.
- ECU identity/VIN are not fabricated. The ECU page distinguishes user-supplied vehicle/ECU context from data actually read in the current session.

## Firmware

`firmware/Nattawut_SmartGauge_V8_Base.ino` is the supplied V8 baseline. Preserve a backup before flashing. Firmware/app integration for RAW frame streaming and remote DTC operations still requires protocol-level verification and physical testing with the Honda Wave 110i S4 ECU.

## Version

Android versionName: `3.0-racing-ui` (UI update / integration stage; not a claim that every hardware feature is complete).


## Phone GPS speed integration (2026-11-13)

- The Android app requests runtime location permission and reads real Android GPS speed using `LocationManager.GPS_PROVIDER`.
- While Bluetooth SPP is connected, the app sends `PHONE_SPEED,<kmh>` lines (up to about 6-7 updates/second) to the ESP32.
- The ESP32 Settings page now provides a touchscreen speed-source selector: `PHONE` or `GPS MOD`.
- The selected source is saved in EEPROM address 3. The active source alone drives the dashboard speed value and Bluetooth telemetry.
- Phone speed expires after 3 seconds without a fresh update; the displayed speed becomes 0. Disconnecting/stopping phone GPS also results in a timeout to 0.
- GPS Module mode continues to use the NMEA RMC speed received on the ESP32 GPS UART.
- Test on the actual phone and board with location enabled and a clear GPS sky view. Android may restrict GPS updates when the app is backgrounded or battery-optimized; keep the app active during the initial road test.
