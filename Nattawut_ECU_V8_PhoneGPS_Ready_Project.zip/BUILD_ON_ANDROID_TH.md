# วิธีสร้าง APK ด้วยมือถือ Android ผ่าน GitHub Actions

1. ดาวน์โหลดและแตกไฟล์ ZIP โปรเจกต์นี้ในมือถือ
2. เข้า GitHub และเปิด repository เดิมของคุณ `potpoy909-del/Nattawut-SmartGauge` (หรือ repository ที่ต้องการใช้)
3. อัปโหลด **เนื้อหาภายใน ZIP** ไปไว้ที่โฟลเดอร์หลัก (root) ของ repository ไม่ใช่อัปโหลดไฟล์ ZIP เพียงไฟล์เดียว
4. ต้องมีไฟล์/โฟลเดอร์เหล่านี้ที่ root: `settings.gradle`, `build.gradle`, `gradle.properties`, `app/` และ `.github/workflows/android-build.yml`
5. สำคัญ: ต้องอัปโหลดโฟลเดอร์ `.github/workflows` ด้วย หากมองไม่เห็น `.github` ในแอปแตก ZIP ให้เปิดการแสดงไฟล์ที่ซ่อนอยู่
6. เมื่ออัปโหลดเสร็จ เปิดแท็บ **Actions** ของ repository
7. เลือก workflow ชื่อ **Build Nattawut SmartGauge APK**
8. กด **Run workflow** แล้วกดปุ่มยืนยัน Run workflow อีกครั้ง
9. รอจนงานแสดงเครื่องหมายถูกสีเขียวคำว่า **Success**
10. เปิดงานที่สำเร็จ เลื่อนลงส่วน **Artifacts** แล้วแตะ `Nattawut-SmartGauge-debug-apk` เพื่อดาวน์โหลด
11. แตก ZIP ของ Artifact แล้วแตะ `app-debug.apk` เพื่อติดตั้ง หาก Android ถาม ให้เปิดอนุญาตติดตั้งแอปจากแหล่งนี้สำหรับแอป Files/Chrome ที่ใช้เปิดไฟล์

## Firmware

ไฟล์ฐาน Firmware อยู่ที่ `firmware/Nattawut_SmartGauge_V8_Base.ino` ภายใน ZIP และมีไฟล์ INO แยกให้ดาวน์โหลดด้วย ให้อัปโหลดลงบอร์ดเฉพาะหลังตรวจสอบ pin mapping และสำรอง firmware เดิมแล้ว อย่าอัปโหลดไฟล์ทดสอบ Bluetooth คนละเวอร์ชันแทนไฟล์นี้

## ทดสอบ Phone GPS

- ติดตั้งแอปและอนุญาต Location ขณะใช้แอป
- เปิด Location/GPS ของมือถือ และเชื่อม Bluetooth Classic กับบอร์ด
- เปิดหน้า GPS ในแอปเพื่อเริ่มส่งความเร็ว
- บนบอร์ดเลือกแหล่งความเร็ว PHONE ใน Settings
- ทดสอบกลางแจ้งโดยให้มือถือรับ GPS ได้ชัดเจน และจอดรถ/ทดสอบอย่างปลอดภัยก่อนใช้งานจริง
