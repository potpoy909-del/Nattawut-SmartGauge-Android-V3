# NATTAWUT SMARTGAUGE Android V2.2

โปรเจกต์ Android Kotlin สำหรับ Honda Wave 110i ECU S4 และ ESP32 CYD ผ่าน Bluetooth Classic SPP

## หน้าจอในแอป 12 หน้า
1. Dashboard — แสดงค่า Telemetry 13 ช่อง; ค่าไม่พร้อมแสดง `--`
2. Live Graph — กราฟจากค่าที่ได้รับจริง เลือก RPM/TPS/ECT/BAT/SPEED
3. Logger — บันทึกข้อมูลที่ได้รับจาก Bluetooth พร้อมเวลา และส่งออก CSV
4. DTC Scanner — แสดงสถานะความพร้อม; คำสั่งอ่าน/ลบถูกล็อกจนยืนยัน API
5. ECU Information — ข้อมูลโปรโตคอลและสถานะการเชื่อมต่อ
6. MAP Manager — หน้าจัดการ MAP; การซิงก์ ECU/SD ยังรอ API
7. ECU Remap — เลือก BIN, ตรวจขนาด, SHA-256, ส่งออกรายงาน; เขียน ECU ถูกล็อก
8. Bluetooth Manager — เชื่อมต่อ/ตัดการเชื่อมต่ออุปกรณ์ที่จับคู่แล้ว
9. Remote Control — แสดงรายการควบคุมที่รอ Firmware API; ยังไม่ส่งคำสั่ง
10. Data Center — สรุป Log/Telemetry และส่งออก CSV
11. Vehicle Profile — Honda Wave 110i 2009 / ECU S4 / K-Line 10400
12. Settings — สถานะโปรโตคอลและตัดการเชื่อมต่อ

## โปรโตคอล Bluetooth
`NATTWUT,1,RPM,TPS,ECT,IAT,BAT,O2,AFR,SPEED,INJ,IGN,MAP,STFT,LTFT`

แอปใช้ Bluetooth Classic SPP (RFCOMM). เฟิร์มแวร์ต้องส่ง CSV v1 ตามลำดับฟิลด์นี้. ค่าที่เป็น `NA` จะแสดง `--` และไม่ถูกแทนด้วยศูนย์หรือค่าจำลอง.

## ข้อจำกัดที่ต้องทราบ
- Logger รุ่นนี้บันทึกข้อมูล/บรรทัดที่แอปได้รับผ่าน Bluetooth RX. ไม่ใช่การดักจับ K-Line TX/RX ทุกไบต์แบบ passive; เฟิร์มแวร์ปัจจุบันยังไม่ได้ส่ง TX และทุกเฟรม K-Line มาให้แอปครบถ้วน
- DTC read/clear, MAP sync, Remote Control, Auto-connect และการเขียน ECU ยังไม่เปิด เพราะ API ฝั่ง ESP32 ยังไม่ได้รับการยืนยัน/ทดสอบ
- Remap page ทำได้เฉพาะจัดการไฟล์ BIN ในระดับเลือกไฟล์ ตรวจขนาด/แฮช และรายงาน. ปุ่มเขียน ECU ถูกล็อกเพื่อป้องกัน ECU เสีย
- ประวัติการรีแมพก่อนติดตั้งแอปไม่สามารถอ่านยืนยันจาก ECU ได้ จึงไม่สร้างตัวเลขย้อนหลังขึ้นมาเอง
- โปรไฟล์ ROM 38770-K58-T81 / 64 KB / Start 0x8000 / Checksum 0x0000 เป็นข้อมูลอ้างอิงจากตารางที่ผู้ใช้ให้ ต้องตรวจยืนยันกับ ROM จริงก่อนใช้งาน
- ต้องใช้ ESP32 รุ่นที่รองรับ Bluetooth Classic SPP; บอร์ด ESP32-S2/S3/C3 ไม่รองรับ SPP แบบนี้

## Build APK ด้วย GitHub Actions
Workflow อยู่ที่ `.github/workflows/android-build.yml` เมื่ออัปโหลด source เข้า repository และ push ไป `main` ระบบจะ build `app-debug.apk` และแนบ Artifact ชื่อ `Nattawut-SmartGauge-debug-apk`

## Firmware reference
โฟลเดอร์ `firmware/` มีสำเนา sketch `Nattawut_SmartGauge_V3_RAW_Logger.ino` จากไฟล์ล่าสุดที่มีในโปรเจกต์. อย่าอัปโหลดทับบอร์ดเพียงเพราะอยู่ใน ZIP; ใช้เฉพาะเมื่อยืนยันว่าเป็นเวอร์ชันที่ใช้งานอยู่และขาต่อ/การตั้งค่าตรงกับบอร์ดจริง
