# วิธี Build APK ผ่านมือถือ Android

1. ดาวน์โหลด ZIP source แล้วแตกไฟล์
2. อัปโหลด **เนื้อหาทั้งหมดภายในโฟลเดอร์โปรเจกต์** เข้า repository GitHub โดยให้ `app/`, `gradle/`, `build.gradle`, `settings.gradle` และ `.github/workflows/android-build.yml` อยู่ที่ระดับราก repository
3. เปิดแท็บ Actions แล้วรอ workflow `Build Nattawut SmartGauge APK` ทำงานหลัง push (หรือกด Run workflow)
4. เมื่อสถานะ Success เปิดงานล่าสุด เลื่อนลง Artifacts แล้วดาวน์โหลด `Nattawut-SmartGauge-debug-apk`
5. แตกไฟล์ Artifact แล้วติดตั้ง `app-debug.apk` บน Android

## หมายเหตุสำคัญ
- Build Success ยืนยันว่า source compile ผ่านเท่านั้น ไม่ได้ยืนยันการทำงานกับรถ/ECU จริง
- จับคู่ Bluetooth `Nattawut ECU` จาก Android Settings ก่อน แล้วจึงเปิดแอปและกด CONNECT
- หาก Android ขอสิทธิ์ Nearby devices/Bluetooth ให้กดอนุญาต
- ฟังก์ชันที่ต้องมี API เพิ่มใน ESP32 เช่น DTC, MAP Sync, Remote Control และ ECU Write ยังถูกล็อกไว้
- อย่าแฟลช ECU ด้วยแอปนี้; การเขียน ROM ยังไม่รองรับและไม่ปลอดภัยจนกว่าจะยืนยันโปรโตคอลเฉพาะ ECU
