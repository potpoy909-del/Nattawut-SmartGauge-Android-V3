package com.nattawut.ecu

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothSocket
import android.content.pm.PackageManager
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.core.app.ActivityCompat
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStream
import java.util.UUID
import kotlin.concurrent.thread
import kotlin.math.max

class MainActivity : Activity() {
    private val bg = Color.rgb(4, 10, 23)
    private val panel = Color.rgb(12, 24, 46)
    private val panel2 = Color.rgb(17, 34, 62)
    private val cyan = Color.rgb(0, 220, 245)
    private val blue = Color.rgb(0, 95, 255)
    private val muted = Color.rgb(155, 174, 202)
    private val white = Color.WHITE
    private var page = "Home"
    private var btSocket: BluetoothSocket? = null
    private var btOut: OutputStream? = null
    private var btConnected = false
    private var locationManager: LocationManager? = null
    private var gpsActive = false
    private var lastSpeed = 0.0
    private var rawLog = mutableListOf<String>()
    private val telemetry = linkedMapOf("RPM" to "0", "TPS" to "0", "ECT" to "--", "IAT" to "--", "BAT" to "--", "O2" to "--", "AFR" to "--", "SPEED" to "0", "INJ" to "--", "IGN" to "--", "MAP" to "--", "STFT" to "--", "LTFT" to "--")
    private lateinit var root: LinearLayout
    private lateinit var content: LinearLayout
    private lateinit var status: TextView
    private val mainHandler = Handler(Looper.getMainLooper())
    private val spp = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = bg; window.navigationBarColor = Color.BLACK
        locationManager = getSystemService(LOCATION_SERVICE) as LocationManager
        render()
    }

    private fun render() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(bg) }
        val header = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 14, 18, 10); setBackgroundColor(Color.rgb(5,13,30)) }
        header.addView(label("NATTAWUT SMARTGAUGE V8", 22f, cyan, true))
        header.addView(label("SMART DASHBOARD  •  DIAGNOSE  •  REMAP  •  GPS", 10f, muted, true))
        status = label(if (btConnected) "● CONNECTED" else "● DISCONNECTED", 13f, if (btConnected) Color.GREEN else Color.rgb(255,65,80), true)
        status.setPadding(0, 8, 0, 0); header.addView(status)
        root.addView(header)
        if (page != "Home") {
            val bar = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(12, 6, 12, 6) }
            val back = button("‹  HOME", panel2, cyan) { page = "Home"; render() }
            bar.addView(back, LinearLayout.LayoutParams(100, 42)); bar.addView(label(page, 18f, white, true).apply { setPadding(14,0,0,0) })
            root.addView(bar)
        }
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(14, 10, 14, 20) }
        scroll.addView(content); root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
        when (page) {
            "Home" -> homePage(); "Dashboard" -> dashboardPage(); "Live Data" -> livePage(); "DTC Scanner" -> dtcPage(); "ECU Remap" -> remapPage(); "GPS Speed" -> gpsPage(); "Setting" -> settingsPage(); "Bluetooth" -> bluetoothPage(); "Log / History" -> logPage(); "About" -> aboutPage(); "Signal Guide" -> signalGuide()
        }
    }

    private fun homePage() {
        content.addView(card { addView(label("SMARTGAUGE V8", 25f, cyan, true)); addView(label("HONDA PGM-FI  •  K-LINE  •  BLUETOOTH SPP", 11f, muted)); addView(label(if (btConnected) "● ESP32 CONNECTED" else "● ESP32 DISCONNECTED", 16f, if (btConnected) Color.GREEN else Color.RED, true).apply { setPadding(0,12,0,0) }) })
        val names = listOf("Dashboard", "Live Data", "DTC Scanner", "ECU Remap", "GPS Speed", "Setting", "Bluetooth", "About", "Log / History")
        val desc = listOf("หน้าปัดแสดงค่ารถแบบเรียลไทม์", "ข้อมูลเซ็นเซอร์และกราฟ", "อ่านและจัดการรหัสผิดปกติ", "เลือกและตรวจสอบไฟล์ BIN", "รับความเร็วจาก GPS มือถือ", "ตั้งค่าแหล่งความเร็วและระบบ", "เชื่อมต่อบอร์ด ESP32 CYD", "เวอร์ชันและข้อมูลแอป", "ประวัติและไฟล์บันทึก")
        val icons = listOf("◉", "▥", "⚠", "▦", "⌖", "⚙", "ᛒ", "ⓘ", "≡")
        for (i in names.indices step 2) {
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            for (j in i until minOf(i+2,names.size)) {
                val tile = card { gravity = Gravity.CENTER_VERTICAL; addView(label(icons[j], 26f, cyan, true)); addView(label(names[j].uppercase(), 14f, cyan, true).apply { setPadding(0,7,0,3) }); addView(label(desc[j], 10f, muted)) }
                tile.setOnClickListener { page = names[j]; render() }
                row.addView(tile, LinearLayout.LayoutParams(0, 122, 1f).apply { setMargins(4,4,4,4) })
            }
            content.addView(row)
        }
        content.addView(label("ข้อมูล ECU ที่ยังไม่ได้รับจะแสดงเป็น -- ไม่สร้างค่าจำลอง", 11f, muted).apply { setPadding(4,14,4,4) })
    }

    private fun dashboardPage() {
        content.addView(label("VEHICLE SPEED", 12f, muted, true))
        content.addView(GaugeView(this, telemetry["SPEED"]?.toFloatOrNull() ?: 0f), LinearLayout.LayoutParams(-1, 270))
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("ECT" to "อุณหภูมิน้ำหล่อเย็น", "BAT" to "แรงดันแบตเตอรี่", "TPS" to "ตำแหน่งลิ้นเร่ง").forEach { (k,d) -> row.addView(metricCard(k, telemetry[k] ?: "--", d), LinearLayout.LayoutParams(0,95,1f).apply { setMargins(3,3,3,3) }) }
        content.addView(row)
        content.addView(card { addView(label("ENGINE RPM", 12f, muted)); addView(label("${telemetry["RPM"]} rpm", 30f, cyan, true)); addView(label("ค่า RPM จะเปลี่ยนเมื่อได้รับข้อมูลจาก ECU", 11f, muted)) })
        content.addView(button("เปิดข้อมูลเซ็นเซอร์ทั้งหมด", blue, white) { page="Live Data"; render() })
        content.addView(label("GPS / PH  •  แหล่งความเร็วเลือกได้ใน Setting", 11f, muted).apply { setPadding(6,12,0,0) })
    }

    private fun livePage() {
        content.addView(label("LIVE SENSOR TELEMETRY", 13f, cyan, true))
        content.addView(label("ค่าที่ไม่รองรับหรือยังไม่ได้รับจะแสดง --", 11f, muted))
        telemetry.forEach { (key,value) ->
            val unit = units[key] ?: ""
            val r = LinearLayout(this).apply { gravity=Gravity.CENTER_VERTICAL; setPadding(12,10,12,10); setBackgroundColor(panel); orientation=LinearLayout.HORIZONTAL }
            val names = sensorNames[key] ?: key
            r.addView(LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; addView(label(key,15f,white,true)); addView(label(names,10f,muted)) }, LinearLayout.LayoutParams(0,-2,1f))
            r.addView(label("$value $unit",16f,cyan,true))
            content.addView(r,LinearLayout.LayoutParams(-1,-2).apply { setMargins(0,4,0,4) })
        }
        content.addView(button("อธิบายความหมายสัญญาณทั้งหมด", blue, white) { page="Signal Guide"; render() })
    }

    private fun dtcPage() {
        content.addView(card { addView(label("DTC DIAGNOSTIC",18f,white,true)); addView(label("ระบบตรวจรหัสความผิดปกติ ECU",12f,muted)); addView(label("ยังไม่มีคำสั่ง DTC ผ่าน Bluetooth ที่ยืนยันกับ Firmware รุ่นนี้",12f,Color.rgb(255,190,60)))} )
        content.addView(label("รายการรหัสผิดปกติ",16f,cyan,true))
        content.addView(card { addView(label("ยังไม่มีข้อมูลรหัส DTC",15f,muted)); addView(label("เมื่อเชื่อมต่อ API อ่าน DTC ที่ผ่านการทดสอบแล้ว รหัสจะแสดงในหน้านี้",11f,muted)) })
        content.addView(button("อ่านรหัส (Read DTC)", blue, white) { toast("ยังไม่ส่งคำสั่ง ECU: ต้องเพิ่มและทดสอบคำสั่ง DTC ใน Firmware ก่อน") })
        content.addView(button("ล้างรหัส (Clear DTC)", Color.rgb(190,105,0), white) { toast("ปิดการล้าง DTC ไว้จนกว่าจะยืนยันคำสั่งและขั้นตอนความปลอดภัย") })
        content.addView(button("รีเฟรช", panel2, white) { toast("ยังไม่มีข้อมูล DTC จากบอร์ด") })
    }

    private fun remapPage() {
        content.addView(card { addView(label("ECU REMAP",20f,cyan,true)); addView(label("เลือกไฟล์ BIN จากมือถือเพื่อตรวจสอบข้อมูล",12f,muted)); addView(label("การเขียนไฟล์ลง ECU ถูกล็อกไว้จนกว่าจะยืนยัน ECU ID, โปรโตคอล, checksum, backup และ recovery",11f,Color.rgb(255,190,60))) })
        content.addView(button("เลือกไฟล์ BIN", blue, white) { val i=android.content.Intent(android.content.Intent.ACTION_OPEN_DOCUMENT).apply { type="*/*"; addCategory(android.content.Intent.CATEGORY_OPENABLE) }; startActivityForResult(i,79) })
        content.addView(label("ยังไม่ได้เลือกไฟล์",13f,muted).apply { tag="bin_status"; setPadding(8,12,8,12) })
        content.addView(button("เขียนไฟล์ไปยัง ECU", Color.DKGRAY, muted) { toast("ฟังก์ชันเขียน ECU ยังถูกล็อกเพื่อป้องกันความเสียหาย") })
    }

    override fun onActivityResult(requestCode:Int,resultCode:Int,data:android.content.Intent?) { super.onActivityResult(requestCode,resultCode,data); if(resultCode!=RESULT_OK) return; val uri=data?.data ?: return; if(requestCode==79){ val name=uri.lastPathSegment ?: "ไฟล์ BIN"; val v=root.findViewWithTag<TextView>("bin_status"); v?.text="เลือกไฟล์แล้ว: $name\nURI: $uri\nตรวจสอบขนาด/Checksum เพิ่มเติมก่อนใช้งาน" }; if(requestCode==80){ try { contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { w -> w.write("record_type,time_ms,raw_data\n"); rawLog.forEach { w.write("RAW,,\"${it.replace("\"","\"\"")}\"\n") } }; toast("ส่งออก RAW LOG แล้ว") } catch(e:Exception){ toast("ส่งออกไม่สำเร็จ: ${e.message}") } } }

    private fun gpsPage() {
        content.addView(card { addView(label("GPS พร้อมใช้งาน",16f,Color.GREEN,true)); addView(label("PHONE GPS  •  Android Location",11f,muted)); addView(label("${"%.1f".format(lastSpeed)}",54f,white,true)); addView(label("km/h",18f,cyan,true)) })
        content.addView(button("เริ่ม GPS", Color.rgb(0,150,50), white) { startGps() })
        content.addView(button("หยุด GPS", Color.rgb(190,25,45), white) { stopGps() })
        content.addView(label("เมื่อมีตำแหน่ง GPS และเชื่อมต่อบอร์ด ระบบจะส่ง SPEED,<km/h> ผ่าน Bluetooth SPP",11f,muted).apply { setPadding(6,12,6,6) })
    }

    private fun settingsPage() {
        content.addView(label("เลือกแหล่งความเร็ว",15f,white,true))
        val rg=RadioGroup(this).apply { orientation=RadioGroup.VERTICAL; setPadding(10,8,10,8); setBackgroundColor(panel) }
        val a=RadioButton(this).apply { text="GPS MODULE (จากบอร์ด)"; setTextColor(white) }; val b=RadioButton(this).apply { text="PHONE BT (GPS มือถือ)"; setTextColor(white); isChecked=true }; rg.addView(a);rg.addView(b);content.addView(rg)
        listOf("โหมดแสดงผลแบบเต็มจอ","เสียงแจ้งเตือน","บันทึกข้อมูลอัตโนมัติ").forEach { title -> val sw=Switch(this).apply { text=title; setTextColor(white); isChecked=true; setPadding(10,12,10,12) }; content.addView(sw) }
        content.addView(button("บันทึกการตั้งค่า",blue,white){toast("บันทึกการตั้งค่าในหน้าจอนี้แล้ว")})
    }

    private fun bluetoothPage() {
        content.addView(card { addView(label("BLUETOOTH CLASSIC SPP",18f,cyan,true)); addView(label(if(btConnected) "● CONNECTED" else "● DISCONNECTED",16f,if(btConnected) Color.GREEN else Color.RED,true)); addView(label("เชื่อมต่อกับ ESP32 SmartGauge เพื่อรับ Telemetry CSV v1, ACK, STATUS และ RAW",11f,muted)) })
        content.addView(button("ค้นหาอุปกรณ์ที่จับคู่",blue,white){showPairedDevices()})
        content.addView(button("ตัดการเชื่อมต่อ",Color.rgb(175,25,45),white){disconnectBt();render()})
        content.addView(button("ส่ง PING ทดสอบ",panel2,white){sendBt("PING\n")})
    }

    private fun logPage() {
        content.addView(label("LOG / HISTORY",18f,cyan,true)); content.addView(label("บันทึก RAW และข้อมูลที่ได้รับจากบอร์ด",11f,muted))
        content.addView(label("จำนวนบรรทัดที่บันทึก: ${rawLog.size}",14f,white,true))
        rawLog.takeLast(30).reversed().forEach { content.addView(card { addView(label(it,10f,muted)) }) }
        content.addView(button("ส่งออก RAW LOG",blue,white){exportLog()})
        content.addView(button("ลบประวัติ",Color.rgb(170,25,45),white){rawLog.clear();render()})
    }

    private fun aboutPage() {
        content.addView(card { gravity=Gravity.CENTER; addView(label("◜  SMARTGAUGE  ◝",25f,cyan,true)); addView(label("NATTAWUT",23f,white,true)); addView(label("SMARTGAUGE V8",17f,cyan,true)); addView(label("เวอร์ชันแอป: 1.0.0 Fresh UI",13f,white)); addView(label("ผู้พัฒนา: Nattawut",13f,muted)); addView(label("ระบบ: Android • Bluetooth SPP • ESP32 CYD",11f,muted)) })
    }

    private fun signalGuide() {
        content.addView(label("ความหมายของสัญญาณเซ็นเซอร์",18f,cyan,true)); content.addView(label("รายการนี้อธิบายชื่อย่อ หน่วย และหน้าที่ ไม่ได้หมายความว่า ECU ของรถส่งค่าทุกรายการได้",11f,muted))
        signalDescriptions.forEach { (k,v) -> content.addView(card { addView(label(k,16f,cyan,true)); addView(label(v,12f,white)) }) }
    }

    private fun showPairedDevices() {
        if(Build.VERSION.SDK_INT>=31 && ActivityCompat.checkSelfPermission(this,Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){ ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.BLUETOOTH_CONNECT),31); toast("อนุญาต Bluetooth แล้วกดค้นหาอีกครั้ง"); return }
        val adapter=BluetoothAdapter.getDefaultAdapter(); if(adapter==null){toast("โทรศัพท์ไม่รองรับ Bluetooth");return}
        val devices=adapter.bondedDevices?.toList() ?: emptyList(); if(devices.isEmpty()){toast("ยังไม่มีอุปกรณ์ที่จับคู่ ให้จับคู่ ESP32 ในการตั้งค่า Android ก่อน");return}
        AlertDialog.Builder(this).setTitle("เลือก ESP32 ที่จับคู่แล้ว").setItems(devices.map{"${it.name ?: "Unknown"}  ${it.address}"}.toTypedArray()){_,which->connectBt(devices[which].address)}.setNegativeButton("ยกเลิก",null).show()
    }

    private fun connectBt(address:String) { thread { try { val adapter=BluetoothAdapter.getDefaultAdapter(); val d=adapter.getRemoteDevice(address); if(Build.VERSION.SDK_INT>=31 && ActivityCompat.checkSelfPermission(this,Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED){mainHandler.post{ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.BLUETOOTH_CONNECT),31)};return@thread}; adapter.cancelDiscovery(); val s=d.createRfcommSocketToServiceRecord(spp); s.connect(); btSocket=s;btOut=s.outputStream;btConnected=true; mainHandler.post{render();toast("เชื่อมต่อ ESP32 แล้ว")}; readLoop(s) } catch(e:Exception){btConnected=false;mainHandler.post{render();toast("เชื่อมต่อไม่สำเร็จ: ${e.message}")}} } }
    private fun readLoop(s:BluetoothSocket){ try { val reader=BufferedReader(InputStreamReader(s.inputStream)); while(s.isConnected){ val line=reader.readLine() ?: break; synchronized(rawLog){rawLog.add(line)}; parseTelemetry(line); mainHandler.post{if(page=="Dashboard"||page=="Live Data")render()} } }catch(_:Exception){} finally {btConnected=false;btOut=null;btSocket=null;mainHandler.post{render()} } }
    private fun parseTelemetry(line:String){ if(line.startsWith("NATTWUT,")){val p=line.split(','); val keys=listOf("RPM","TPS","ECT","IAT","BAT","O2","AFR","SPEED","INJ","IGN","MAP","STFT","LTFT"); keys.forEachIndexed{i,k-> if(i+2<p.size) telemetry[k]=p[i+2] } } else if(line.startsWith("RAW")||line.startsWith("BT_RAW")||line.startsWith("TELEMETRY")){/* preserved in raw log */} }
    private fun sendBt(s:String){try{btOut?.write(s.toByteArray());btOut?.flush()}catch(e:Exception){toast("ยังไม่ได้เชื่อมต่อ Bluetooth")}}
    private fun disconnectBt(){try{btSocket?.close()}catch(_:Exception){};btSocket=null;btOut=null;btConnected=false}

    private fun startGps(){ if(ActivityCompat.checkSelfPermission(this,Manifest.permission.ACCESS_FINE_LOCATION)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,arrayOf(Manifest.permission.ACCESS_FINE_LOCATION,Manifest.permission.ACCESS_COARSE_LOCATION),42);return}; try{gpsActive=true;locationManager?.requestLocationUpdates(LocationManager.GPS_PROVIDER,1000,0f,gpsListener);toast("เริ่มรับ GPS แล้ว")}catch(e:Exception){toast("เปิด GPS ไม่สำเร็จ: ${e.message}")} }
    private val gpsListener=object:LocationListener{override fun onLocationChanged(loc:Location){lastSpeed=if(loc.hasSpeed()) max(0.0,loc.speed*3.6) else 0.0;sendBt("SPEED,${"%.1f".format(java.util.Locale.US,lastSpeed)}\n");if(page=="GPS Speed")render()}}
    private fun stopGps(){gpsActive=false;try{locationManager?.removeUpdates(gpsListener)}catch(_:Exception){};toast("หยุด GPS แล้ว")}
    private fun exportLog(){ val i=android.content.Intent(android.content.Intent.ACTION_CREATE_DOCUMENT).apply{addCategory(android.content.Intent.CATEGORY_OPENABLE);type="text/csv";putExtra(android.content.Intent.EXTRA_TITLE,"Nattawut_RAW_Log.csv")};startActivityForResult(i,80) }
    private fun toast(s:String){Toast.makeText(this,s,Toast.LENGTH_LONG).show()}
    private fun label(s:String,size:Float,color:Int,bold:Boolean=false)=TextView(this).apply{text=s;textSize=size;setTextColor(color);if(bold) setTypeface(typeface,android.graphics.Typeface.BOLD)}
    private fun card(block:LinearLayout.()->Unit)=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(14,14,14,14);setBackgroundColor(panel);block();background=android.graphics.drawable.GradientDrawable().apply{setColor(panel);cornerRadius=18f;setStroke(2,Color.rgb(25,100,155))};layoutParams=LinearLayout.LayoutParams(-1,-2).apply{setMargins(2,6,2,6)}}
    private fun button(text:String,color:Int,txt:Int,on:()->Unit)=Button(this).apply{this.text=text;setTextColor(txt);textSize=14f;background=android.graphics.drawable.GradientDrawable().apply{setColor(color);cornerRadius=30f;setStroke(1,cyan)};setOnClickListener{on()};layoutParams=LinearLayout.LayoutParams(-1,52).apply{setMargins(2,6,2,6)}}
    private fun metricCard(k:String,v:String,d:String)=card{addView(label(k,12f,cyan,true));addView(label(v,20f,white,true));addView(label(d,9f,muted))}
    override fun onDestroy(){stopGps();disconnectBt();super.onDestroy()}

    private inner class GaugeView(ctx:android.content.Context,val speed:Float):View(ctx){val p=Paint(3);override fun onDraw(c:Canvas){super.onDraw(c);val cx=width/2f;val cy=height/2f;val radius=minOf(width,height)*.39f; p.style=Paint.Style.STROKE;p.strokeWidth=18f;p.strokeCap=Paint.Cap.ROUND;p.color=Color.rgb(24,48,80);c.drawArc(RectF(cx-radius,cy-radius,cx+radius,cy+radius),135f,270f,false,p);p.color=cyan;c.drawArc(RectF(cx-radius,cy-radius,cx+radius,cy+radius),135f,(speed.coerceIn(0f,180f)/180f)*270f,false,p);p.style=Paint.Style.FILL;p.textAlign=Paint.Align.CENTER;p.color=white;p.textSize=58f;c.drawText(speed.toInt().toString(),cx,cy+10,p);p.textSize=19f;p.color=cyan;c.drawText("km/h",cx,cy+42,p);p.textSize=12f;p.color=muted;c.drawText("RPM × 1000  •  ${telemetry["RPM"]}",cx,cy+radius*.65f,p)}}

    companion object {
        val units=mapOf("RPM" to "rpm","TPS" to "%","ECT" to "°C","IAT" to "°C","BAT" to "V","O2" to "V","AFR" to "λ","SPEED" to "km/h","INJ" to "ms","IGN" to "°","MAP" to "kPa","STFT" to "%","LTFT" to "%")
        val sensorNames=mapOf("RPM" to "รอบเครื่องยนต์","TPS" to "ตำแหน่งลิ้นเร่ง","ECT" to "อุณหภูมิน้ำหล่อเย็น","IAT" to "อุณหภูมิอากาศไอดี","BAT" to "แรงดันแบตเตอรี่","O2" to "แรงดันเซ็นเซอร์ออกซิเจน","AFR" to "อัตราส่วนอากาศต่อเชื้อเพลิง","SPEED" to "ความเร็วรถ","INJ" to "ระยะเวลาการฉีดน้ำมัน","IGN" to "องศาจุดระเบิด","MAP" to "แรงดันสัมบูรณ์ท่อร่วมไอดี","STFT" to "การปรับเชื้อเพลิงระยะสั้น","LTFT" to "การปรับเชื้อเพลิงระยะยาว")
        val signalDescriptions=listOf("RPM — Engine Speed" to "รอบเครื่องยนต์ หน่วย rpm บอกจำนวนรอบเพลาข้อเหวี่ยงต่อนาที ใช้ดูรอบเดินเบาและรอบขณะเร่ง", "TPS — Throttle Position Sensor" to "ตำแหน่งลิ้นเร่ง หน่วย % บอกการเปิดคันเร่ง 0% คือปิด และค่ามากขึ้นคือเปิดมากขึ้น", "ECT — Engine Coolant Temperature" to "อุณหภูมิน้ำหล่อเย็น หน่วย °C ใช้ดูอุณหภูมิเครื่องยนต์และการอุ่นเครื่อง", "IAT — Intake Air Temperature" to "อุณหภูมิอากาศไอดี หน่วย °C ใช้ประเมินความหนาแน่นของอากาศที่เข้าสู่เครื่องยนต์", "BAT — Battery Voltage" to "แรงดันไฟเลี้ยง หน่วย V ใช้ตรวจสภาพระบบไฟและแรงดันขณะเครื่องยนต์ทำงาน", "O2 — Oxygen Sensor" to "แรงดันเซ็นเซอร์ออกซิเจน หน่วย V สะท้อนออกซิเจนในไอเสีย ทั้งนี้ชนิด narrowband/wideband ให้การแปลผลต่างกัน", "AFR — Air Fuel Ratio" to "อัตราส่วนมวลอากาศต่อเชื้อเพลิง หรือค่า lambda ตามรูปแบบข้อมูล ECU ต้องตรวจสอบสเกลก่อนแปลผล", "SPEED — Vehicle Speed" to "ความเร็วรถ หน่วย km/h อาจมาจาก ECU หรือ GPS มือถือ/โมดูล ต้องระบุแหล่งที่ใช้", "INJ — Injector Pulse Width" to "ระยะเวลาการเปิดหัวฉีด หน่วย ms ใช้บอกเวลาฉีดเชื้อเพลิงต่อรอบ/เหตุการณ์ตามกลยุทธ์ ECU", "IGN — Ignition Timing" to "องศาจุดระเบิด หน่วยองศา ใช้บอกเวลาจุดประกายเทียบตำแหน่งเพลาข้อเหวี่ยง", "MAP — Manifold Absolute Pressure" to "แรงดันสัมบูรณ์ในท่อร่วมไอดี หน่วย kPa ใช้ประเมินโหลดเครื่องยนต์", "STFT — Short Term Fuel Trim" to "ค่าชดเชยเชื้อเพลิงระยะสั้น หน่วย % เป็นการปรับทันทีจาก feedback เซ็นเซอร์", "LTFT — Long Term Fuel Trim" to "ค่าชดเชยเชื้อเพลิงระยะยาว หน่วย % เป็นการเรียนรู้ชดเชยสะสมของ ECU")
    }
}
