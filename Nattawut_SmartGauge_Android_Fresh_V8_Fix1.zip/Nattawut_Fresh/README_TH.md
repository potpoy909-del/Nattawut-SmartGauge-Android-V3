# Nattawut SmartGauge V8 — Fresh Android App

โปรเจกต์ Android นี้สร้างหน้าแอปใหม่ทั้งหมด ไม่ได้นำ Activity หรือหน้า UI จากแอป Stage 3 เดิมมาใช้ โดยยึดโปสเตอร์ SmartGauge V8 ที่แนบใน `reference/` เป็นแนวทางหน้าตาและโครงสร้าง 10 หน้า

## 10 หน้า
1. Home — เมนูหลัก 9 การ์ดเพื่อเข้า 8 ฟังก์ชันหลักและ Log/History
2. Dashboard — หน้าปัดความเร็ว, RPM, ECT, BAT, TPS
3. Live Data — ตารางข้อมูลเซ็นเซอร์ทั้งหมด
4. DTC Scanner — พื้นที่แสดงรหัสและปุ่ม Read/Clear/Refresh
5. ECU Remap — เลือกไฟล์ BIN และแสดงข้อมูลไฟล์
6. GPS Speed — รับ GPS จาก Android และส่ง `SPEED,<km/h>\n` ผ่าน SPP เมื่อเชื่อมต่อ
7. Setting — เลือกแหล่งความเร็วและตั้งค่าหน้าจอ/เสียง/บันทึก
8. Bluetooth — เลือกอุปกรณ์ที่จับคู่แล้วและเชื่อมต่อ Bluetooth Classic SPP
9. Log/History — เก็บบรรทัด RAW ที่รับและส่งออก CSV
10. About — เวอร์ชันและข้อมูลแอป

## ความหมายสัญญาณ
- RPM: รอบเครื่องยนต์ (rpm)
- TPS: ตำแหน่งลิ้นเร่ง (%)
- ECT: อุณหภูมิน้ำหล่อเย็น (°C)
- IAT: อุณหภูมิอากาศไอดี (°C)
- BAT: แรงดันแบตเตอรี่ (V)
- O2: แรงดันเซ็นเซอร์ออกซิเจน (V; ต้องทราบชนิดเซ็นเซอร์ก่อนแปลผล)
- AFR: อัตราส่วนอากาศต่อเชื้อเพลิง/ค่า lambda ตามสเกลที่ ECU ส่ง
- SPEED: ความเร็วรถ (km/h)
- INJ: ระยะเวลาการฉีดน้ำมัน (ms)
- IGN: องศาจุดระเบิด (°)
- MAP: แรงดันสัมบูรณ์ท่อร่วมไอดี (kPa)
- STFT/LTFT: ค่าชดเชยเชื้อเพลิงระยะสั้น/ระยะยาว (%)

## ข้อจำกัดที่ตั้งใจล็อกไว้เพื่อความปลอดภัย
- DTC: หน้าจอพร้อม แต่ Firmware ที่อ้างอิงยังไม่มี API Bluetooth READ/CLEAR DTC ที่ยืนยันแล้ว จึงยังไม่ส่งคำสั่ง ECU จากแอป
- ECU Remap: เลือกไฟล์ BIN ได้ แต่ยังไม่เขียนไฟล์ลง ECU จนกว่าจะยืนยัน ECU ID, protocol, checksum, backup และ recovery
- ค่าเซ็นเซอร์ที่ยังไม่รับจริงจะแสดง `--` ไม่สร้างข้อมูล ECU จำลอง

## Build
ใช้ GitHub Actions workflow `.github/workflows/android-build.yml` เพื่อ build `:app:assembleDebug` และดาวน์โหลด artifact `Nattawut-SmartGauge-V8-Fresh-APK`
