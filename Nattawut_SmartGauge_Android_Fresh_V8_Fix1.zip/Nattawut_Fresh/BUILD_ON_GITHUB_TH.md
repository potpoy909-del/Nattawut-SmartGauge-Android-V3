1. อัปโหลด `Nattawut_SmartGauge_Android_Fresh_V8.zip` ไปที่ root ของ Repository
2. แทนที่ไฟล์ `.github/workflows/android-build.yml` ด้วย workflow ที่อยู่ใน ZIP (หรือใช้ไฟล์เดียวกันนี้)
3. เปิดแท็บ Actions แล้วเลือก Build Nattawut SmartGauge V8 APK
4. รอให้เป็น Success แล้วเปิด run ล่าสุด
5. ดาวน์โหลด Artifact ชื่อ Nattawut-SmartGauge-V8-Fresh-APK แล้วแตก ZIP เพื่อได้ app-debug.apk
